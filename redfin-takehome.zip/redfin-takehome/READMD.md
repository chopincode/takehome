## Take Home Demo

#### Run the program
Open a terminal on Linux/OSX machine, go to the project folder and install all required dependencies.
To do so, simply run

```npm install```

Then in the same terminal, run

```node FoodTruckFinder.js```

You should be able to use the command line as an interactive tool to play with the project.
Make sure you have <b>npm</b> and <b>node.js</b> installed on your machine first.

#### Methodology
1. Using vanilla JS or other HTTP library to fetch the body from the api will give us the raw data in string format.
2. Parsing the string will give us a clearer format of the data structure for each JSON object. Then we need to filter and process useful information from each of them.
3. Calculate current time in minute will let us find the open truck more easily. Do the same for each truck's open and close time (24h)
4. Filter the truck using three standards (1) Current time must be larger than open time and smaller than close time (2) Open day must be the day we are looking for (3) Validate the data is not null or undefined
5. Using a set will help us filter out duplicated object.
6. Sort the answer alphabetically by comparing the ```NAME``` field of each object in the result array
7. Let user interact with the project by command line prompt. If there are more than 10 trucks available for them to view, they have the option to continue or kill the program.