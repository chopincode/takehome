const { exit } = require("process");
const request = require("request");
const prompt = require("prompt-sync")();

request(
  "http://data.sfgov.org/resource/bbb8-hzi6.json",
  function (error, response, body) {
    if (error) {
      console.log(error);
      return;
    }

    const now = new Date();

    const curTime = getCurrentTimeInMin(now);
    const curDay = now.getDay();

    const trucks = JSON.parse(body);
    const openTrucks = findTrucksOpenNow(trucks, curTime, curDay);

    const truckCount = openTrucks.length;

    console.log(`We have found ${truckCount} open trucks`);
    console.log("We display the top 10 trucks for you");

    if (truckCount <= 10) {
      console.log(openTrucks);
    } else {
      console.log(openTrucks.slice(0, 10));
      
      let counter = 10;
      while (counter <= truckCount) {
        const option = prompt(
          "Do you want to view more? Press y/Y to continue, other key to exit "
        );
        if (option === "Y" || option === 'y') {
          console.log(openTrucks.slice(counter, counter + 10));
          counter += 10;
        } else {
          exit(1);
        }
      }
    }
  }
);

// filter trucks which are open at time when you run the program
function findTrucksOpenNow(trucks, curTime, curDay) {
  const openTrucks = new Set();

  for (const truck of trucks) {
    const [start, end] = convert24HourTime(truck);
    let dayOfWeek = +truck.dayorder;

    if (curTime > start && curTime < end) {
      if (dayOfWeek === curDay) {
        if (truck.applicant && truck.location) {
          openTrucks.add({ NAME: truck.applicant, ADDRESS: truck.location });
        }
      }
    }
  }

  return Array.from(openTrucks).sort((a, b) => (a.NAME > b.NAME ? 1 : -1));
}

// calculate current time in terms of minute
function getCurrentTimeInMin(now) {
  const hour = now.getHours();
  const min = now.getMinutes();

  return hour * 60 + min;
}

// convert start and end time to minute of each truck from their 24 hour time stamp
function convert24HourTime(truck) {
  let startHour = +truck.start24.substring(0, 2);
  let startMin = +truck.start24.substring(3, 5);
  let endHour = +truck.end24.substring(0, 2);
  let endMin = +truck.end24.substring(3, 5);

  let start = startHour * 60 + startMin;
  let end = endHour * 60 + endMin;

  return [start, end];
}

// to run locally, first install node and npm. then:
// $ npm install request && node FoodTruckFinder.js
